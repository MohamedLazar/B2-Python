#!/usr/bin/env python3

# 1a-add.py
# Addition de deux nombres
# 15/10/2018
# Mohamed Lazar

nb1 = int(input('Entre le nb1 : '))
nb2 = int(input('Entre le nb2 : '))
print(nb1+nb2)



